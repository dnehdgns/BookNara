package com.booknara.booknaraPrj.admin.report;

public enum AdminReportState {
    PENDING, RESOLVED
}