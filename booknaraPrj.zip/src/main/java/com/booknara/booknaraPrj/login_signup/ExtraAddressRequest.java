package com.booknara.booknaraPrj.login_signup;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExtraAddressRequest {
    private String zipcode;
    private String addr;
    private String detailAddr;
}
