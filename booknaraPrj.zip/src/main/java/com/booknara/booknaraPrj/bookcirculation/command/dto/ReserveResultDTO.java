package com.booknara.booknaraPrj.bookcirculation.command.dto;

import lombok.Data;

@Data
public class ReserveResultDTO {
    private String rsvId;
    private String isbn13;
}