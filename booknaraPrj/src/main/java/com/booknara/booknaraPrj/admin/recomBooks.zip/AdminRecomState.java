package com.booknara.booknaraPrj.admin.recomBooks;

public enum AdminRecomState {
    active, inactive
}
