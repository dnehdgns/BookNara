package com.booknara.booknaraPrj.ebook.dto;

public class EBookDTO {
}
